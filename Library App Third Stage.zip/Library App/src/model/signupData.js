const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Library');
const Schema = mongoose.Schema;
const signupSchema = new Schema({
    firstname:String,
    middlename:String,
    lastname:String,
    phonenumber:String,
    email:String,
    password:String,
    confirmpassword:String
});

var signupdata = mongoose.model('signupdata',signupSchema);
module.exports = signupdata;